
import requests
import asyncio
import logging

from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes
)

logging.basicConfig(level=logging.INFO)

TOKEN = "9043329363:AAEcpUBsmCqoWaGTa-7seh9b_-LliYRMlC4"


def feriados(ano):
    try:
        url = f"https://date.nager.at/api/v3/PublicHolidays/{ano}/BR"

        resposta = requests.get(url, timeout=10)

        if resposta.status_code == 200:
            return resposta.json()

        return []

    except requests.RequestException as erro:
        logging.error(f"Erro na API: {erro}")
        return []


def formatar(lista, ano):
    texto = f"🇧🇷 FERIADOS DE {ano}\n\n"

    for f in lista:
        data = datetime.strptime(
            f["date"], "%Y-%m-%d"
        ).strftime("%d/%m/%Y")

        texto += (
            f"📅 {data}\n"
            f"🎉 {f['localName']}\n"
            f"📌 {', '.join(f['types'])}\n\n"
        )

    return texto


def menu():
    botoes = [
        [InlineKeyboardButton("📅 Feriados 2026", callback_data="2026")],
        [InlineKeyboardButton("📅 Feriados 2027", callback_data="2027")],
        [InlineKeyboardButton("🔎 Próximo feriado", callback_data="proximo")],
        [InlineKeyboardButton("❓ Ajuda", callback_data="ajuda")]
    ]

    return InlineKeyboardMarkup(botoes)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "*BOT DE FERIADOS*\n\n"
        "Consulte os feriados nacionais do Brasil "
        "através da API Nager.Date.\n\n"
        "Escolha uma opção:",
        parse_mode="Markdown",
        reply_markup=menu()
    )


async def botoes(update: Update, context: ContextTypes.DEFAULT_TYPE):

    query = update.callback_query
    await query.answer()

    if query.data in ["2026", "2027"]:

        ano = int(query.data)

        lista = await asyncio.to_thread(feriados, ano)

        if lista:
            await query.edit_message_text(
                formatar(lista, ano),
                reply_markup=menu()
            )
        else:
            await query.edit_message_text(
                "Não foi possível consultar os feriados.",
                reply_markup=menu()
            )

    elif query.data == "proximo":

        ano = datetime.now().year
        hoje = datetime.now().date()

        lista = await asyncio.to_thread(feriados, ano)

        proximo = next(
            (
                f for f in lista
                if datetime.strptime(
                    f["date"], "%Y-%m-%d"
                ).date() >= hoje
            ),
            None
        )

        if not proximo:
            lista = await asyncio.to_thread(feriados, ano + 1)

            proximo = next(
                (
                    f for f in lista
                    if datetime.strptime(
                        f["date"], "%Y-%m-%d"
                    ).date() >= hoje
                ),
                None
            )

        if not proximo:
            await query.edit_message_text(
                "Não foi possível encontrar o próximo feriado.",
                reply_markup=menu()
            )
            return

        data = datetime.strptime(
            proximo["date"], "%Y-%m-%d"
        ).strftime("%d/%m/%Y")

        texto = (
            "🔎 *PRÓXIMO FERIADO*\n\n"
            f"🎉 *{proximo['localName']}*\n"
            f"📅 {data}\n"
            f"📌 {', '.join(proximo['types'])}"
        )

        await query.edit_message_text(
            texto,
            parse_mode="Markdown",
            reply_markup=menu()
        )

    elif query.data == "ajuda":

        await query.edit_message_text(
            "*AJUDA*\n\n"
            "/start - Abrir o menu\n"
            "/feriados2026 - Feriados de 2026\n"
            "/feriados2027 - Feriados de 2027\n"
            "/proximo - Próximo feriado",
            parse_mode="Markdown",
            reply_markup=menu()
        )


async def comando_feriados(update, context):

    ano = int(update.message.text[-4:])

    lista = await asyncio.to_thread(feriados, ano)

    if lista:
        await update.message.reply_text(
            formatar(lista, ano),
            reply_markup=menu()
        )
    else:
        await update.message.reply_text(
            "Erro ao consultar a API."
        )


async def proximo(update, context):
    await update.message.reply_text(
        "Use o botão abaixo para consultar:",
        reply_markup=menu()
    )


def main():

    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("feriados2026", comando_feriados))
    app.add_handler(CommandHandler("feriados2027", comando_feriados))
    app.add_handler(CommandHandler("proximo", proximo))

    app.add_handler(CallbackQueryHandler(botoes))

    print("Bot iniciado!")

    app.run_polling()


if __name__ == "__main__":
    main()
